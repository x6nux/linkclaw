import { EventSource } from "eventsource";
import type { MCPClient } from "./mcp-client.js";

/** LinkClaw 消息事件 payload */
interface MessageNewPayload {
  message_id: string;
  company_id: string;
  channel_id?: string;
  receiver_id?: string;
  sender_id?: string;
  msg_type: string;
  content: string;
  created_at: string;
}

/** LinkClaw 任务事件 payload */
interface TaskPayload {
  task_id: string;
  title: string;
  description?: string;
  assignee_id?: string;
  status?: string;
}

export type InboundHandler = (message: {
  id: string;
  channel: string;
  senderId: string;
  text: string;
  timestamp: string;
  metadata?: Record<string, unknown>;
}) => void;

/**
 * LinkClaw 通道：负责 SSE 事件监听和消息收发
 *
 * - inbound: 通过 Agent SSE 接收实时事件，转发给 OpenClaw agent 处理
 * - outbound: 通过 MCP send_message 工具发送消息
 */
export class LinkClawBridge {
  private es: EventSource | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private pingTimer: ReturnType<typeof setInterval> | null = null;
  private handler: InboundHandler | null = null;
  private selfId = "";

  constructor(private mcp: MCPClient) {}

  /** 设置自身 ID（用于过滤自己发的消息） */
  setSelfId(id: string) { this.selfId = id; }

  /** 注册入站消息处理器 */
  onInbound(handler: InboundHandler) { this.handler = handler; }

  /** 启动 SSE 事件流 + MCP 心跳 */
  start() {
    this.connectSSE();
    this.pingTimer = setInterval(() => {
      this.mcp.ping().catch(() => {});
    }, 30_000);
  }

  /** 发送文本消息到 LinkClaw */
  async sendText(opts: { text: string; channel?: string; recipientId?: string }) {
    const args: Record<string, unknown> = { content: opts.text };
    if (opts.channel) args.channel = opts.channel;
    if (opts.recipientId) args.receiver_id = opts.recipientId;
    await this.mcp.callTool("send_message", args);
  }

  stop() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.pingTimer) clearInterval(this.pingTimer);
    this.es?.close();
    this.es = null;
  }

  // ── SSE 连接 ──────────────────────────────────────────────

  private connectSSE() {
    const url = this.mcp.agentSSEUrl;
    const token = this.mcp.token;

    this.es = new EventSource(url, {
      fetch: (input, init) =>
        fetch(input, {
          ...init,
          headers: { ...(init?.headers ?? {}), Authorization: `Bearer ${token}` },
        }),
    });

    const events = ["message.new", "task.created", "task.updated"];
    for (const type of events) {
      this.es.addEventListener(type, (evt) => {
        try {
          const raw = JSON.parse((evt as MessageEvent).data);
          const payload = raw.payload ?? raw;
          this.dispatch(type, payload);
        } catch { /* ignore parse errors */ }
      });
    }

    this.es.onerror = () => {
      this.es?.close();
      this.es = null;
      this.reconnectTimer = setTimeout(() => this.connectSSE(), 5000);
    };
  }

  private dispatch(type: string, payload: unknown) {
    if (!this.handler) return;

    if (type === "message.new") {
      const p = payload as MessageNewPayload;
      if (p.sender_id === this.selfId) return;
      if (p.msg_type !== "text") return;

      const channel = p.receiver_id
        ? `dm:${p.sender_id}`
        : `channel:${p.channel_id ?? "unknown"}`;

      this.handler({
        id: p.message_id,
        channel,
        senderId: p.sender_id ?? "system",
        text: p.content,
        timestamp: p.created_at,
        metadata: { channelId: p.channel_id, receiverId: p.receiver_id },
      });
    }

    if (type === "task.created" || type === "task.updated") {
      const p = payload as TaskPayload;
      const prefix = type === "task.created" ? "[新任务]" : "[任务更新]";
      const text = `${prefix} ${p.title}${p.description ? "\n" + p.description : ""}`;
      this.handler({
        id: `task-${p.task_id}-${Date.now()}`,
        channel: "tasks",
        senderId: "system",
        text,
        timestamp: new Date().toISOString(),
        metadata: { taskId: p.task_id, status: p.status, assigneeId: p.assignee_id },
      });
    }
  }
}
